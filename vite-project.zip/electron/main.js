const { app, BrowserWindow } = require('electron')
const path = require('path')
const createWindow = () => {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences:{
      contextIsolation:false,// 是否开启隔离上下文
      nodeIntegration: true,// 渲染进程使用node api

    }
  })
  if(app.isPackaged){
    win.loadFile(path.join(__dirname,'../dist/index.html'))
  }else{
    let url ='http://127.0.0.1:5173/'
    win.loadURL(url)
  }

 
}

app.whenReady().then(() => {
  createWindow()

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})