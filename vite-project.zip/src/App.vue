
<template>
  <div>

    <img src="/vite.svg" class="logo" alt="Vite logo" @click="login" />


  </div>
  <HelloWorld msg="Vite + Vue" />
</template>
 

<script setup>
import HelloWorld from './components/HelloWorld.vue'
import axios from 'axios'
import qs from 'qs'
import { onMounted, ref } from "vue";
const img = ref(null);
onMounted(() => {
  getCode()
})

const getCode = () => {
  imageUrlToBase64('/api/defaultKaptcha')
}


const imageUrlToBase64 = (imageUrl) => {
  let image = new Image() // 一定要设置为let，不然图片不显示
  image.setAttribute('crossOrigin', 'anonymous') // 解决跨域问题
  image.src = imageUrl
  image.onload = () => {
    var canvas = document.createElement("canvas");
    canvas.width = image.width;
    canvas.height = image.height;
    var ctx = canvas.getContext("2d");
    ctx.drawImage(image, 0, 0, image.width, image.height);
    var dataURL = canvas.toDataURL("image/jpeg");

    base64toFile(dataURL)
  }
}

const base64toFile = (dataurl, filename = 'file') => {
  let arr = dataurl.split(',')
  let mime = arr[0].match(/:(.*?);/)[1]
  let suffix = mime.split('/')[1]
  let bstr = atob(arr[1])
  let n = bstr.length
  let u8arr = new Uint8Array(n)
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n)
  }
  let file = new File([u8arr], `${filename}.${suffix}`, {
    type: mime
  })
  recognize(file)
}


const recognize = async (file) => {
  const worker = await Tesseract.createWorker({
    logger: m => console.log(m)
  });
  Tesseract.setLogging(true);
  await worker.load();
  await worker.loadLanguage('eng');
  await worker.initialize('eng')


  let result = await worker.recognize(file, 'eng');
  console.log(result.data.text);
  login(result.data.text)
  await worker.terminate();
}

const login = (checkCode) => {
  const params = {
    loginName: 'gd075999',
    loginPwd: 'Hjk0759',
    checkCode: checkCode.trim(),
  }
  const options = {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    data: qs.stringify(params),
    url: '/api/doLogin',
  };

  axios(options).then(res => {
    console.log(res, 'dddddddd')
    if (res.data === 1) {
      getHtml()
    } else {
      getCode()
    }


  })
}

const getHtml = () => {
  axios.get('/api/index').then(res => {
    const regex = /var\s+__sysinfo\s*=\s*([\s\S]*?);/;
    const match = res.data.match(regex);

    if (match && match.length > 1) {
      const sysinfoStr = match[1];
      const sysinfo = JSON.parse(JSON.parse(sysinfoStr));
      window.__sysinfo = sysinfo
      console.log(sysinfo, 'sysinfo');
      getFrommesg()
    } else {
      console.log('__sysinfo not found.');
    }
  })
}

const getFrommesg = () => {
  const params = {
    __: 'frommesg',
    gameIndex: 3,
    t: window.__sysinfo.autoTid
  }
  const options = {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    data: qs.stringify(params),
    url: '/api/frommesg',
  };

  axios(options).then(res => {
    console.log(res, '123')
  })
}



</script>
 

<style scoped>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}

.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}

.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}
</style>
